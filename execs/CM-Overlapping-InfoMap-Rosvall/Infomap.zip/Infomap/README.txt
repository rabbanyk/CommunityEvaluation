Infomap Software Package


Authors:
--------------------------------------------------------
Daniel Edler
Martin Rosvall

For contact information, see 
http://www.mapequation.org/about

For a list of recent feature updates, see
CHANGES.txt in the source directory.

Terms of use:
--------------------------------------------------------
The Infomap software is released under a dual licence.

To give everyone maximum freedom to make use of Infomap 
and derivative works, we make the code open source under 
the GNU Affero General Public License version 3 or any 
later version (see LICENSE_AGPLv3.txt.)

For a non-copyleft license, please contact us.


Getting started:
--------------------------------------------------------
In a terminal with the GNU Compiler Collection installed,
just run 'make' in the current directory to compile the
code with the included Makefile. Call ./Infomap to run.

For more info, see
http://www.mapequation.org/code