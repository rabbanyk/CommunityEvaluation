readme.txt file for LineGraphCreator Version 091222

Look at the LineGraphCreator.html file for more information.

The linegraphcreator.exe was created on a Windows XP machine
using the MinGW gnu C++ compiler under a Netbeans IDE. It
should work on most Windows PCs.

For Linux or Macs refer the LineGraphCreator.html file for how
I compiled it, it should be similar on most machines.

Author: T.S.Evans, Physics Dept., Imperial College London

These line graphs are defined in the paper by T.S.Evans and
R.Lambiotte, Line Graphs, Link Partitions and Overlapping
Communities, Phys.Rev.E 80 (2009) 016105 [arXiv:0903.2181].
Please cite this paper and acknowledge use of this code if you
use this code.

More details on weighted graphs is in arXiv:0912.4389.
