#
g++ -c -O3 -o TseGraph.o TseGraph.cpp
g++ -c -O3 -o LineGraphCreator.o LineGraphCreator.cpp
g++ -o linegraphcreator TseGraph.o LineGraphCreator.o
